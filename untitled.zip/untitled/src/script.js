window.onload = function(){


    // بعد 5 ثواني ينتهي الدخول وتظهر الصفحة

    setTimeout(function(){


        document.getElementById("intro").style.display = "none";


        document.getElementById("app").style.display = "block";


    },5000);



};




// تغيير الصفحات

function openPage(pageID){


    let pages = document.querySelectorAll(".page");



    pages.forEach(function(page){


        page.classList.remove("active");


    });



    document.getElementById(pageID).classList.add("active");


}